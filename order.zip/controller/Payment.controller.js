sap.ui.define([
	"com/csr/order/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/csr/order/model/formatter",
	"com/csr/order/util/OrderServiceUtil"
], function(BaseController, JSONModel, formatter, OrderServiceUtil) {
	"use strict";

	return BaseController.extend("com.csr.order.controller.Payment", {

		formatter: formatter,
		OrderServiceUtil: OrderServiceUtil,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.csr.order.view.Payment
		 */
		onInit: function() {
			var oViewModel = this.createViewModel();
			this.getView().setModel(oViewModel, "paymentViewModel");
			this.getOwnerComponent().getRouter().getRoute("Payment").attachPatternMatched(this.onObjectMatched, this);
			this.oEventBus = this.getEventBus();
		},
		createViewModel: function() {
			return new JSONModel({
				"delay": 0,
				"busy": false,
				"CardSet": [],
				"CashSet": [{}],
				"PrintReceipt": true,
				"EmailReceipt": false,
				"changeAmount": "0.00",
				"displayBackButton": true
				
			});
		},
		onObjectMatched: function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var orderHeaderModel = this.getOwnerComponent().getModel("orderHeaderModel");
			var cartHeaderModel = this.getOwnerComponent().getModel("cartHeaderModel");
			oViewModel.setProperty("/busy", true);
			var totalAmount = orderHeaderModel.getProperty("/totalAmount");
			var email = cartHeaderModel.getProperty("/email");
			oViewModel.setProperty("/totalAmount", totalAmount);
			oViewModel.setProperty("/payableAmount", totalAmount);
			oViewModel.setProperty("/paid", "0.00");
			if (email) {
				oViewModel.setProperty("/email", email);
			}
			this.getAssestID();
			this.createMonthModel();
			this.createYearViewModel();
			this.createCardTypeViewModel();
			this.onAddCard();
		
			oViewModel.setProperty("/busy", false);
			
		},
		
		createMonthModel: function () {
			var monthSet = [];
			for (var monthIndex = 1; monthIndex <= 12; monthIndex++) {
				var oMonth = {};
				var value;
				if (monthIndex <= 9) {
					value =  "0" + monthIndex;
					oMonth.Key = value;
				} else {
					value = monthIndex;
					oMonth.Key = value;
				}
				oMonth.Value = value;
				
				monthSet.push(oMonth);
			}
			var monthViewModel = new JSONModel({});
			monthViewModel.setProperty("/MonthSet", monthSet);
			this.getView().setModel(monthViewModel,"monthViewModel");
		},
		
		createYearViewModel: function () {
			var date = new Date();
			var fullYear = date.getFullYear();
			fullYear = fullYear.toString();
			var year = fullYear.substring(2,fullYear.length);
			var yearSet = [];
			for (var yearIndex = 1; yearIndex <= 10; yearIndex++) {
				var oYear = {};
				oYear.Key = year;
				oYear.Value = year;
				yearSet.push(oYear);
				year++;
			}
			var yearViewModel = new JSONModel({});
			yearViewModel.setProperty("/YearSet", yearSet);
			this.getView().setModel(yearViewModel,"yearViewModel");
			
		},
		createCardTypeViewModel: function () {
			var cardTypesViewModel = new JSONModel({
				"CardTypes":
					[
						{
							"Key": "",
							"Value": ""
						},
						{
							"Key": "MASTERCARD",
							"Value": "MASTERCARD"
						},
						{
							"Key": "VISA",
							"Value": "VISA"
						}
					]
				
			});
			this.getView().setModel(cardTypesViewModel,"cardTypesViewModel");
		},
		onCardPayment: function (oEvent) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var oCardBindingContext = oEvent.getSource().getParent().getBindingContext("paymentViewModel");
			var cardPath = oCardBindingContext.sPath;
			var isCardDetailsValid = false;
			var cardDetails = oViewModel.getProperty(cardPath);
			var referenceNo = cardDetails.referenceNo;
			if (!referenceNo) {
				isCardDetailsValid = this.validateCardAmount(cardPath);
				var isPaymentValid = this.updateAmountValues();
				if (isCardDetailsValid && isPaymentValid) {
					oViewModel.setProperty("/busy", true);
					this.triggerCardPayment(cardDetails, cardPath);
					oViewModel.setProperty(cardPath + "/showAmountValueStateMessage", false);
					oViewModel.setProperty(cardPath + "/amountValueState", "None");
				} else {
					oViewModel.setProperty(cardPath + "/showAmountValueStateMessage", true);
					oViewModel.setProperty(cardPath + "/amountValueState", "Error");
				}
			}
		},
		onAddCard: function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			oViewModel.setProperty("/busy", true);
			var cardItems = oViewModel.getProperty("/CardSet");
			var cardsCount = cardItems.length;
			var card = {};
			card.cardAmount = oViewModel.getProperty("/payableAmount");
			card.isEditable = true;
			oViewModel.setProperty("/CardSet/" + cardsCount, card);
			oViewModel.setProperty("/busy", false);
		},
		onCashAmountChange: function (oEvent) {
			this.updateAmountValues(true);
			this.updateCardAmountValue();
		},
		updateAmountValues: function (isCash) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var totalAmount = oViewModel.getProperty("/totalAmount");
			var cashSet = oViewModel.getProperty("/CashSet");
			var cashCount = cashSet.length;
			var cardSet = oViewModel.getProperty("/CardSet");
			var cardCount = cardSet.length;
			var cashAmount = 0;
			var cardAmount = 0;
			var paidValue = 0;
			var payableAmount = 0;
			var changeAmount = 0;
			for (var cashIndex = 0; cashIndex < cashCount; cashIndex++) {
				var cash = cashSet[cashIndex];
				if (cash.Cash) {
					cash.Cash = cash.Cash.replace(/,/g, "");
					cashAmount += parseFloat(cash.Cash);
				}
			}
			for (var cardIndex = 0; cardIndex < cardCount; cardIndex++) {
				var card = cardSet[cardIndex];
				if (card.cardAmount && !card.isEditable) {
					card.cardAmount = card.cardAmount.replace(/,/g, "");
					cardAmount += parseFloat(card.cardAmount);
				}
			}
			paidValue = parseFloat(cashAmount) + parseFloat(cardAmount);
			payableAmount = parseFloat(totalAmount) - parseFloat(paidValue);
			
			if(payableAmount < 0 && !isCash) {
				sap.m.MessageToast.show(
					this.getResourceBundle().getText("paidValueValidation"),
					{
						duration: 6000
					});
				return false;
			} else {
				
				if (payableAmount < 0) {
					changeAmount = (payableAmount) * - 1;
					payableAmount = 0;
				}
				paidValue = parseFloat(paidValue).toFixed(2);
				payableAmount = parseFloat(payableAmount).toFixed(2);
				changeAmount = parseFloat(changeAmount).toFixed(2);
				oViewModel.setProperty("/paid", paidValue);
				oViewModel.setProperty("/payableAmount", payableAmount);
				oViewModel.setProperty("/changeAmount", changeAmount);
				return true;
			}
		},
		updateCardAmountValue : function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var cardItems = oViewModel.getProperty("/CardSet");
			var cardsCount = cardItems.length;
			var card;
			var cardPath;
			if (cardsCount >= 0) {
				cardPath = cardsCount - 1;
				card = oViewModel.getProperty("/CardSet/" + cardPath);
				card.cardAmount = oViewModel.getProperty("/payableAmount");
			}
			oViewModel.refresh();
		},
		onCardAmountChange: function (oEvent) {
			var oCardBindingContext = oEvent.getSource().getParent().getBindingContext("paymentViewModel");
			var cardPath = oCardBindingContext.sPath;
			this.validateCardAmount(cardPath);
		},
		validateCardAmount: function (cardPath) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var payableAmount = oViewModel.getProperty("/payableAmount");
			var cardDetails = oViewModel.getProperty(cardPath);
			var cardAmountValue = parseFloat(cardDetails.cardAmount);
			var payableAmountValue = parseFloat(payableAmount);
			if (cardAmountValue && cardAmountValue <= payableAmountValue) {
				oViewModel.setProperty(cardPath + "/showAmountValueStateMessage", false);
				oViewModel.setProperty(cardPath + "/amountValueState", "None");
				return true;
			} else {
				oViewModel.setProperty(cardPath + "/showAmountValueStateMessage", true);
				oViewModel.setProperty(cardPath + "/amountValueState", "Error");
				return false;
			}
		},
		
		validateComboBox : function (oEvent) {
			var path = oEvent.getSource().getBindingPath("selectedKey");
			var showValueStatePath = oEvent.getSource().getBindingPath("showValueStateMessage");
			var valueStatePath = oEvent.getSource().getBindingPath("valueState");
			var oViewModel = this.getView().getModel("paymentViewModel");
			if (oViewModel.getProperty(path)) {
				oViewModel.setProperty(showValueStatePath, false);
				oViewModel.setProperty(valueStatePath, "None");
				return true;
			} else {
				oViewModel.setProperty(showValueStatePath, true);
				oViewModel.setProperty(valueStatePath, "Error");
				return false;
			}
		},
		
		triggerCardPayment: function (cardDetails, cardPath) {
			var oThis = this;
			var oViewModel = this.getView().getModel("paymentViewModel");
			var orderHeaderModel = this.getOwnerComponent().getModel("orderHeaderModel");
			var currency = orderHeaderModel.getProperty("/currency");
			var vbeln = oViewModel.getProperty("/vbeln");
			
			var cardAmount = oViewModel.getProperty(cardPath + "/cardAmount");
			var cardPartOne = oViewModel.getProperty(cardPath + "/cardPartOne");
			var cardPartTwo = oViewModel.getProperty(cardPath + "/cardPartTwo");
			var cardPartThree = oViewModel.getProperty(cardPath + "/cardPartThree");
			var cardPartFour = oViewModel.getProperty(cardPath + "/cardPartFour");
			var cardType = oViewModel.getProperty(cardPath + "/cardType");
			var expiryMonth = oViewModel.getProperty(cardPath + "/month");
			var expiryYear = oViewModel.getProperty(cardPath + "/year");
			var cardNo;
			
			cardAmount = cardAmount.replace(/,/g, "");
			
			if (cardPartOne && cardPartTwo && cardPartThree && cardPartFour) {
				cardNo = cardPartOne + cardPartTwo + cardPartThree + cardPartFour;
			}
			
			var paymentRequest = {};
			paymentRequest = this.createPaymentHeaderRequest();
			
			var paymentEFT = {};
			var paymentEFTSet = [];
			
			paymentEFT.Waerk = currency;
			paymentEFT.Amount = cardAmount;
			if (expiryMonth && expiryYear && cardNo) {
				paymentEFT.Expiry = expiryMonth + expiryYear;
				paymentEFT.Cardnum = cardNo;
			}
			
			if (vbeln) {
				paymentEFT.Vbeln = vbeln;
			}
			if (cardType) {
				paymentEFT.Cardtype = cardType;
			}
			paymentEFTSet.push(paymentEFT);
			paymentRequest.PaymentEFTSet = paymentEFTSet;
			
			var oModel = this.getModel();
				oModel.setUseBatch(false);
				oModel.create("/PaymentHeaderSet", paymentRequest,
					{
						success: function (data) {
							oThis.onCardPaymentSuccessCallback(data, cardPath);
							
						},
						error: function (error) {
							oThis.onCardPaymentErrorCallback(error);
						}
					}
				);	
		},
		onCardPaymentSuccessCallback: function (data, cardPath) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var payableAmount;
			oViewModel.setProperty("/vbeln", data.Vbeln);
			if (data.IsFailed) {
				sap.m.MessageToast.show(
					data.Message,
					{
						duration: 6000
					});
				oViewModel.setProperty("/busy", false);
			} else {
				this.updateCardList(data, cardPath);
				this.onAddCard();
				this.updateAmountValues();
				this.updateCardAmountValue();
				
				payableAmount = oViewModel.getProperty("/payableAmount");
				if (payableAmount <= 0) {
					this.handlePayment();
				} else {
					oViewModel.setProperty("/busy", false);
					sap.m.MessageToast.show(
						this.getResourceBundle().getText("paymentSuccess"),
						{
							duration: 6000
						});
					oViewModel.setProperty("/displayBackButton", false);
				}
			}
		},
		onCardPaymentErrorCallback: function (error) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			oViewModel.setProperty("/busy", false);
			var errorResponse = JSON.parse(error.responseText);
			var errorMessage = errorResponse.error.message.value;
			sap.m.MessageToast.show(
				errorMessage,
				{
					duration: 6000
				});
		},
		updateCardList: function(data, cardPath) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			
			if (data.PaymentEFTSet) {
				var cardSet = data.PaymentEFTSet.results;
				if (cardSet && cardSet.length > 0) {
					var card = cardSet[0];
					var cardEntry = {};
					var cardNo = card.Cardnum;
					if (cardNo) {
						cardEntry.cardPartOne = cardNo.substring(0, 4);
						cardEntry.cardPartTwo = cardNo.substring(4, 8);
						cardEntry.cardPartThree = cardNo.substring(8, 12);
						cardEntry.cardPartFour = cardNo.substring(12, 16);
					}
					cardEntry.cardType = card.Cardtype;
					cardEntry.cardAmount = card.Amount;
					var cardExpiry = card.Expiry;
					if (cardExpiry) {
						cardEntry.month = cardExpiry.substring(0, 2);
						cardEntry.year = cardExpiry.substring(2, 4);
					}
					cardEntry.referenceNo = card.Txnkey;
					cardEntry.isEditable = false;
					oViewModel.setProperty(cardPath, cardEntry);
				}
			}
		},
		
		getAssestID: function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var assestID = sap.ui.getCore().byId("currentAsset");
			var assestIDValue = "";
			var oAssetModel = sap.ui.getCore().getModel("AssetModel");
			if (assestID) {
				assestIDValue = assestID.getValue();
			} else if (oAssetModel){
				assestIDValue = oAssetModel.getProperty("/DefaultAsset");
			}
			oViewModel.setProperty("/assestID", assestIDValue);
		},
		createPaymentHeaderRequest : function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var oCustomerModel = this.getOwnerComponent().getModel("customerModel");
			var cartHeaderModel = this.getOwnerComponent().getModel("cartHeaderModel");
			var orderHeaderModel = this.getOwnerComponent().getModel("orderHeaderModel");
			var salesOrg = oCustomerModel.getProperty("/salesOrg");
			var distrubutionChannel = oCustomerModel.getProperty("/distChannel");
			var division =  oCustomerModel.getProperty("/division");
			var deliveryPlant = cartHeaderModel.getProperty("/deliveryPlant");
			var currency = orderHeaderModel.getProperty("/currency");
			var incoTerms1 = orderHeaderModel.getProperty("/incoTerms1");
			var salesOrderType = orderHeaderModel.getProperty("/orderTypeCode");
			var assestID = oViewModel.getProperty("/assestID");
			var totalAmount = oViewModel.getProperty("/totalAmount");
			var vbeln = oViewModel.getProperty("/vbeln");
			var soldToPartyID = orderHeaderModel.getProperty("/soldToPartyID");
			
			var paymentRequest = {};
			paymentRequest.Sydatum = null;
			paymentRequest.Vkorg = salesOrg; 
			paymentRequest.Inco1 = incoTerms1;
			paymentRequest.Werks = deliveryPlant; 
			paymentRequest.Waerk = currency;
			paymentRequest.Spart = division; 
			paymentRequest.Kunnr = soldToPartyID;
			paymentRequest.Vtweg = distrubutionChannel;
			paymentRequest.Posamt = totalAmount;
			if (vbeln) {
				paymentRequest.Vbeln = vbeln;
			}
			if (assestID) {
				paymentRequest.Assetid = assestID;
			}
			paymentRequest.Auart = salesOrderType;
			
			return paymentRequest;
		},
		handlePayment: function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var isCashAvailable = this.isCashAvailable();
			var isEligibleForOrderCreate = this.isEligibleForOrderCreate();
			if (isEligibleForOrderCreate) {
				oViewModel.setProperty("/busy", true);
				if (isCashAvailable) {
					this.triggerPayment();
				} else {
					this.triggerCreateOrderService();
				}
			} else {
				sap.m.MessageToast.show(
					this.getResourceBundle().getText("fullPaymentMsg"),
					{
						duration:6000
					});
			}
		},
		isEligibleForOrderCreate : function () {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var orderHeaderModel = this.getOwnerComponent().getModel("orderHeaderModel");
			var payableAmount = oViewModel.getProperty("/payableAmount");
			var salesOrderType = orderHeaderModel.getProperty("/orderTypeCode");
			if (salesOrderType === "YIO" && payableAmount <= 0) {
				return true;
			} else if (salesOrderType !== "YIO") {
				return true;
			} else {
				return false;
			}
		},
		isCashAvailable : function() {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var cashSet = oViewModel.getProperty("/CashSet");
			var cashCount = cashSet.length;
			for (var cashIndex = 0; cashIndex < cashCount; cashIndex++) {
				var cash = cashSet[cashIndex];
				var cashAmount = cash.Cash;
				if (cashAmount) {
					return true;
				}
			}
			return false;
		},
		triggerPayment: function () {
			var oThis = this;
			var oViewModel = this.getView().getModel("paymentViewModel");
			var paymentRequest = this.createPaymentHeaderRequest();
			var cashSet = oViewModel.getProperty("/CashSet");
			var cashCount = cashSet.length;
			var paymentCashSet = [];
			var paymentEFTSet = [];
			var paymentCash;
			var cash;
			var cashAmount;
			paymentRequest.PaymentEFTSet = paymentEFTSet;
			
			for (var cashIndex = 0; cashIndex < cashCount; cashIndex++) {
				cash = cashSet[cashIndex];
				cashAmount = cash.Cash;
				cashAmount = cashAmount.replace(/,/g, "");
				if (cashAmount) {
					paymentCash = {};
					paymentCash.Cash = cashAmount;
				}
				paymentCashSet.push(paymentCash);
			}
			paymentRequest.PaymentCashSet = paymentCashSet;
			
			var oModel = this.getModel();
				oModel.setUseBatch(false);
				oModel.create("/PaymentHeaderSet", paymentRequest,
					{
						success: function (data) {
							oThis.onPaymentSuccessCallback(data);
							
						},
						error: function (error) {
							oThis.onPaymentErrorCallback(error);
						}
					}
				);	
		},
		onPaymentSuccessCallback: function(data) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			oViewModel.setProperty("/vbeln", data.Vbeln);
			if (data.IsFailed) {
				sap.m.MessageToast.show(
					data.Message,
					{
						duration: 6000
					});
				oViewModel.setProperty("/busy", false);
			} else {
				sap.m.MessageToast.show(this.getResourceBundle().getText("paymentSuccess"));
				this.triggerCreateOrderService();
			}
		},
		onPaymentErrorCallback: function(error) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			oViewModel.setProperty("/busy", false);
			var errorResponse = JSON.parse(error.responseText);
			var errorMessage = errorResponse.error.message.value;
			sap.m.MessageToast.show(
				errorMessage,
				{
					duration: 6000
				});
		},
		
		triggerCreateOrderService: function() {
			var oThis = this;
			var oViewModel = this.getView().getModel("paymentViewModel");
			var orderHeaderModel = this.getOwnerComponent().getModel("orderHeaderModel");
			var createOrderRequest = OrderServiceUtil.getHeaderForCreateOrder.apply(this);
			var salesOrderTypeCode = orderHeaderModel.getProperty("/orderTypeCode");
			var salesOrderID = oViewModel.getProperty("/vbeln");
			
			var deliveryBlockCode = oViewModel.getProperty("/deliveryBlockType");
			var bilingBlockCode = oViewModel.getProperty("/billingBlockType");
			var payableAmount = oViewModel.getProperty("/payableAmount");
			payableAmount = parseFloat(payableAmount, [10]);
			
			createOrderRequest.SalesOrderID = salesOrderID;
			createOrderRequest.DeliveryBlockCode = deliveryBlockCode;
			createOrderRequest.BillingBlockCode = bilingBlockCode;
			
			if (payableAmount <= 0) {
				createOrderRequest.Zzpaidfull = "X";
			}
			
			var noteSet = OrderServiceUtil.getHeaderTextForCreateOrder.apply(this);
			createOrderRequest.HeaderTextSet = noteSet;
			var vbelnRef = orderHeaderModel.getProperty("/VbelnRef");
			if (vbelnRef) {
				createOrderRequest.VbelnRef = vbelnRef;
			}
				
			var HeaderPartnerSet = [];
			var partner = OrderServiceUtil.getHeaderPartnerForRequest.apply(this); 
			HeaderPartnerSet.push(partner);
			createOrderRequest.HeaderPartnerSet = HeaderPartnerSet;
			
			if (salesOrderTypeCode !== "YIO" && salesOrderTypeCode !== "YQT") {
				var requestedDeliveryDate = orderHeaderModel.getProperty("/requestedDeliveryDate");
				createOrderRequest.RequestedDeliveryDate = this.formatter.formatDate(requestedDeliveryDate);
				
			}  else if (salesOrderTypeCode === "YQT") {
				var validTo = orderHeaderModel.getProperty("/quoteEndDate");
				
				if (validTo) {
					createOrderRequest.Bnddt = this.formatter.formatDate(validTo);
				}
				createOrderRequest.Angdt = this.formatter.formatDate(new Date());
			}
			
			var itemSet = OrderServiceUtil.getItemSetForRequest.apply(this);
			createOrderRequest.ItemSet = itemSet;
			
			var oModel = this.getModel();
				oModel.setUseBatch(false);
				oModel.create("/HeaderSet", createOrderRequest,
					{
						success: function (data) {
							oThis.onOrderCreateSuccessCallback(data);
						},
						error: function (error) {
							oThis.onOrderCreateErrorCallback(error);
						}
					}
				);
		},
		onOrderCreateSuccessCallback: function(data) {
			var salesOrderID = data.SalesOrderID;
			var salesOrderTypeCode = data.SalesOrderTypeCode;
			var cartItemsModel = this.getOwnerComponent().getModel("cartItemsModel");
			var oViewModel = this.getView().getModel("paymentViewModel");
			var itemSet = [];
			var requestedDeliveryDateValue = new Date();
			var cartItem = {};
			var orderMsg;
			var errorMsg = data.ErrorMessage;

			if (requestedDeliveryDateValue) {
				cartItem.deliveryDate = requestedDeliveryDateValue;
			} else {
				cartItem.deliveryDate = new Date();
			}
			itemSet.push(cartItem);
			cartItemsModel.setProperty("/ItemSet",itemSet);
			cartItemsModel.setProperty("/totalItemCount",0);
			cartItemsModel.setProperty("/addButtonEnabled", false);
			cartItemsModel.setProperty("/checkoutButtonEnabled", false);

			// Clear Order Header Values
			OrderServiceUtil.clearValuesInModel.apply(this); 
			this.oEventBus.publish("Payment", "refreshProductList", {});
			this.oEventBus.publish("Payment", "refreshShipToValues", {});

			if (salesOrderTypeCode === "YQT") {
				orderMsg = this.getResourceBundle().getText("quoteCreated",[salesOrderID, errorMsg]);
			} else if (salesOrderTypeCode === "YIO") {
				orderMsg = this.getResourceBundle().getText("immediateOrderCreated",[salesOrderID, errorMsg]);
			} else if (salesOrderTypeCode === "YOR") {
				orderMsg = this.getResourceBundle().getText("standardOrderCreated",[salesOrderID, errorMsg]);
			} else if (salesOrderTypeCode === "YOR1") {
				orderMsg = this.getResourceBundle().getText("thirdPartyOrderCreated",[salesOrderID, errorMsg]);
			} else {
				orderMsg = this.getResourceBundle().getText("salesOrderCreated",[salesOrderID, errorMsg]);
			}
			
			var isPrintReceiptSelected = oViewModel.getProperty("/PrintReceipt");
			var isEmailSelected = oViewModel.getProperty("/EmailReceipt");
			
			if (isPrintReceiptSelected || isEmailSelected) {
				jQuery.sap.delayedCall(3000, this, function() {
					this.triggerReceipt(salesOrderID, orderMsg);
				});
			} else {
				oViewModel.setProperty("/busy", false);
				this.navToHomeScreen(orderMsg);
			}
		},
		onOrderCreateErrorCallback: function(error) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			oViewModel.setProperty("/busy", false);
			var errorResponse = JSON.parse(error.responseText);
			var errorMessage = errorResponse.error.message.value;
			sap.m.MessageToast.show(
				errorMessage,
				{
					duration: 6000
				});
		},
		triggerReceipt : function (documentNo, orderMsg) {
			var oViewModel = this.getView().getModel("paymentViewModel");
			var isPrintReceiptSelected = oViewModel.getProperty("/PrintReceipt");
			var isEmailSelected = oViewModel.getProperty("/EmailReceipt");
			var nacha = "1";
			var email = "";
			if (isPrintReceiptSelected) {
				nacha = "1";
			} 
			if (isEmailSelected) {
				nacha = "7";
				var customerEmail = oViewModel.getProperty("/email");
				if (customerEmail) {
					email = customerEmail;
				}
			}
			if (isPrintReceiptSelected & isEmailSelected) {
				nacha = "1";
			}
			
			var oModel = this.getModel();
			oModel.callFunction(
					"/PrintL", {
	                method: "POST",
	                urlParameters: {
						"Objky": documentNo,"Nacha": nacha ,"PrintInd": "PR", "Email": email
	                },
					success: function (data) {
						oViewModel.setProperty("/busy", false);
					}, 
					error: function (error) {
						oViewModel.setProperty("/busy", false);
						var errorResponse = JSON.parse(error.responseText);
						var errorMessage = errorResponse.error.message.value;
						sap.m.MessageToast.show(
							errorMessage,
							{
								duration: 6000
							});
					}
				}
            ); 
            this.navToHomeScreen(orderMsg);
		},
		navToHomeScreen: function (orderMsg) {
			var oInitialViewModel = this.createViewModel();
			this.getView().setModel(oInitialViewModel, "paymentViewModel");
			sap.m.MessageToast.show(
				orderMsg,
				{
					duration: 6000
				});
			var oModel = this.getModel();
			oModel.setUseBatch(true);
			this.getOwnerComponent().getRouter().navTo("Home", null, true);
		},
		
		onNavBack: function () {
			this.handleCancel();
		},
		handleCancel: function () {
			var oInitialViewModel = this.createViewModel();
			this.getView().setModel(oInitialViewModel, "paymentViewModel");
			this.getOwnerComponent().getRouter().navTo("OrderShipment",null, true);
		}
	
	});

});